package com.example.petraridepilot

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.WindowManager
import java.io.File

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())
    private var last = 0L
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("capture", "Screen capture", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, CaptureService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        startForeground(7, Notification.Builder(this, "capture").setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("Petra Pilot: screen capture").addAction(Notification.Action.Builder(null, "Stop", stop).build()).build())
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val metrics = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val w = metrics.widthPixels; val h = metrics.heightPixels
            val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(intent.getIntExtra("code", Activity.RESULT_OK), data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, handler)
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = r
            r.setOnImageAvailableListener({ source ->
                source.acquireLatestImage()?.use { frame ->
                    val now = SystemClock.elapsedRealtime()
                    if (now - last >= 1000) {
                        last = now
                        val plane = frame.planes[0]
                        val padded = plane.rowStride / plane.pixelStride
                        val bitmap = Bitmap.createBitmap(padded, h, Bitmap.Config.ARGB_8888)
                        bitmap.copyPixelsFromBuffer(plane.buffer)
                        val cropped = Bitmap.createBitmap(bitmap, 0, 0, w, h)
                        val tmp = File(filesDir, "capture.tmp")
                        tmp.outputStream().use { cropped.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                        tmp.renameTo(File(filesDir, "capture.jpg"))
                        if (cropped !== bitmap) cropped.recycle()
                        bitmap.recycle()
                    }
                }
            }, handler)
            display = p.createVirtualDisplay("PetraVision", w, h, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
        } catch (e: Exception) { android.util.Log.e("PetraVision", "Capture failed", e); stopSelf() }
        return START_NOT_STICKY
    }
    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop(); projection = null
        super.onDestroy()
    }
}
