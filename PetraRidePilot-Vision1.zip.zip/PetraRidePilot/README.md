# Petra Ride Pilot — Vision 2 (experimental)

Android 26+, compile/target SDK 35, Java/Kotlin JVM 17. Builds with Gradle 8.9. This is source, not a signed APK. Full Android build and gameplay have not been tested here.

## Changes
- MediaProjection screen capture with user approval; vision runs on a worker thread at a maximum of about 15 frames/s (device dependent).
- Heuristic road/lane, white player car, colored traffic, pothole, coin and shield detection; saved annotated game preview. Coffee/cash recognition and reliable shield state/time-to-collision tracking are not implemented.
- Optional automatic lane selection with manual left/right calibration. It requires explicit START AUTO, a recognized moving game, a known foreground app and current control coordinates. STOP AUTO, loss of game, app switch or stopping capture disarms the pilot. No automatic restart, purchases, network or score submission features.
- The detector is experimental; misses, false positives and crashes are possible. Use only where automation is authorized. Do not use to claim promotional prizes contrary to game terms.

## Try
1. Enable the accessibility service and overlay permission. Start the floating panel and full-screen capture, grant Android's prompt.
2. Open the game. Calibrate the exact two arrow buttons and use the left/right test buttons to confirm. Use a permitted practice session.
3. During gameplay, the floating panel should read GAME L1/L2/L3 and proposed action. START AUTO explicitly arms the experimental pilot; STOP AUTO stops it. A loss of game recognition disarms it.
4. Return to app to view the latest annotated game image (returning also disarms automation). Stop capture when done.

## Offline test
The standalone Kotlin detector was compiled and executed against 59 samples extracted every 3 seconds from the supplied screen recordings. It reported lane geometry in 49 and a player candidate in 46. This is an unlabelled smoke test on development samples, not an accuracy or win-rate measurement. The Android application was not compiled or executed in this environment.
