package com.example.petraridepilot

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var statusView: TextView? = null
    private var autoButton: Button? = null
    private var extras: LinearLayout? = null
    private val update = object : Runnable {
        override fun run() {
            statusView?.text = PilotState.status
            autoButton?.text = if (PilotState.armed) "STOP AUTO" else "START AUTO"
            extras?.visibility = if (PilotState.armed) View.GONE else View.VISIBLE
            handler.postDelayed(this, 300)
        }
    }
    private var calibrationView: View? = null
    private var calibrationStep = 0
    private var leftX = -1f
    private var leftY = -1f
    private var rightX = -1f
    private var rightY = -1f

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        leftX = getSharedPreferences("controls", MODE_PRIVATE).getFloat("leftX", -1f)
        leftY = getSharedPreferences("controls", MODE_PRIVATE).getFloat("leftY", -1f)
        rightX = getSharedPreferences("controls", MODE_PRIVATE).getFloat("rightX", -1f)
        rightY = getSharedPreferences("controls", MODE_PRIVATE).getFloat("rightY", -1f)
        showPanel()
    }

    private fun lp(type: Int, flags: Int = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) =
        WindowManager.LayoutParams(
            (resources.displayMetrics.density * 106).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.LEFT; x = 4; y = 4 }

    private fun overlayType() =
        if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 3, 4, 3)
            setBackgroundColor(0xDD17202A.toInt())
        }
        box.addView(TextView(this).apply {
            text = "PR Pilot"
            setTextColor(Color.WHITE)
            textSize = 16f
        })
        statusView = TextView(this).apply { textSize = 11f; setTextColor(Color.WHITE); text = PilotState.status }
        box.addView(statusView!!)
        autoButton = button("START AUTO") {
            if (PilotState.armed) { PilotState.disarm() }
            else if (!PilotState.capturing || GameAccessibilityService.instance == null || leftX < 0 || rightX < 0) {
                Toast.makeText(this, "فعّل الالتقاط والتحكم وعاير الكبسات", Toast.LENGTH_LONG).show()
            } else if (!PilotState.status.startsWith("GAME") || android.os.SystemClock.elapsedRealtime()-PilotState.lastGameFrame>450) {
                Toast.makeText(this, "افتح اللعبة وابدأ اللعب أولاً", Toast.LENGTH_LONG).show()
            } else {
                val pkg = GameAccessibilityService.foregroundPackage
                if (pkg == null || pkg == packageName || pkg == "com.android.systemui") {
                    Toast.makeText(this, "لم يتم تحديد تطبيق اللعبة", Toast.LENGTH_LONG).show()
                } else {
                    PilotState.leftX=leftX; PilotState.leftY=leftY
                    PilotState.rightX=rightX; PilotState.rightY=rightY
                    PilotState.targetPackage=pkg; PilotState.armed=true
                }
            }
        }
        box.addView(autoButton!!)
        extras = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(button("معايرة الكبسات") { startCalibration() })
            addView(button("اختبار يسار") { testTap(leftX, leftY, "يسار") })
            addView(button("اختبار يمين") { testTap(rightX, rightY, "يمين") })
            addView(button("إخفاء اللوحة") { stopSelf() })
        }
        box.addView(extras!!)
        panel = box
        wm.addView(box, lp(overlayType()))
        handler.post(update)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 10f
        minHeight = 0
        minimumHeight = 0
        setPadding(5, 0, 5, 0)
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun startCalibration() {
        PilotState.disarm()
        if (calibrationView != null) return
        calibrationStep = 0
        val screen = TextView(this).apply {
            text = "المعايرة 1/2\nالمس مكان كبسة اليسار داخل اللعبة"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(0x55000000)
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_UP) {
                    val loc = IntArray(2)
                    getLocationOnScreen(loc)
                    val x = event.rawX
                    val y = event.rawY
                    if (calibrationStep == 0) {
                        leftX = x; leftY = y
                        calibrationStep = 1
                        text = "المعايرة 2/2\nالمس مكان كبسة اليمين داخل اللعبة"
                    } else {
                        rightX = x; rightY = y
                        getSharedPreferences("controls", MODE_PRIVATE).edit()
                            .putFloat("leftX", leftX).putFloat("leftY", leftY)
                            .putFloat("rightX", rightX).putFloat("rightY", rightY).apply()
                        removeCalibration()
                        Toast.makeText(this@OverlayService, "انحفظت مواقع الكبسات", Toast.LENGTH_LONG).show()
                    }
                }
                true
            }
        }
        calibrationView = screen
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        wm.addView(screen, p)
    }

    private fun removeCalibration() {
        calibrationView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        calibrationView = null
    }

    private fun testTap(x: Float, y: Float, label: String) {
        if (x < 0 || y < 0) {
            Toast.makeText(this, "عاير الكبسات أولاً", Toast.LENGTH_SHORT).show()
            return
        }
        PilotState.disarm()
        val service = GameAccessibilityService.instance
        if (service == null) {
            Toast.makeText(this, "فعّل خدمة التحكم من إعدادات إمكانية الوصول", Toast.LENGTH_LONG).show()
            return
        }
        service.tapAt(x, y) {
            Toast.makeText(this, "تم إرسال لمسة اختبار: $label", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        PilotState.disarm()
        handler.removeCallbacks(update)
        removeCalibration()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
