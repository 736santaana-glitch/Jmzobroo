package com.example.petraridepilot

object PilotState {
    @Volatile var lastGameFrame = 0L
    @Volatile var capturing = false
    @Volatile var status = "ابدأ التقاط الشاشة"
    @Volatile var armed = false
    @Volatile var targetPackage: String? = null
    @Volatile var leftX = -1f
    @Volatile var leftY = -1f
    @Volatile var rightX = -1f
    @Volatile var rightY = -1f
    fun disarm() { armed = false; targetPackage = null }
}
