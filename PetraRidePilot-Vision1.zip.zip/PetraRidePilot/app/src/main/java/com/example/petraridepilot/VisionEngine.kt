package com.example.petraridepilot

import kotlin.math.*

data class Mark(val lane: Int, val x: Int, val y: Int, val kind: String, val score: Float)
data class Road(val a: Int, val b: Int, val top: Int, val bottom: Int) {
    val laneWidth get() = b-a
    fun center(lane: Int) = (a + (lane-.5)*laneWidth).roundToInt()
}
data class Detection(val road: Road? = null, val player: Mark? = null, val objects: List<Mark> = emptyList())
enum class DrivingAction { LEFT, RIGHT, HOLD, STOP }

/** Coordinates are in a small, aspect-preserving RGB frame. No Android dependency. */
object VisionEngine {
    private fun red(c: Int) = c shr 16 and 255
    private fun green(c: Int) = c shr 8 and 255
    private fun blue(c: Int) = c and 255
    private fun line(c: Int): Boolean {
        val r=red(c); val g=green(c); val b=blue(c)
        return r in 93..205 && g in 75..170 && r-g in 6..65 && g-b in 28..115
    }
    private fun white(c: Int): Boolean {
        val r=red(c); val g=green(c); val b=blue(c)
        return min(r,min(g,b)) > 155 && max(r,max(g,b))-min(r,min(g,b)) < 45
    }
    private fun dark(c: Int): Boolean = max(red(c),max(green(c),blue(c))) < 76
    private fun hole(c: Int): Boolean = max(red(c),max(green(c),blue(c))) < 33
    private fun color(c: Int): Boolean {
        val r=red(c); val g=green(c); val b=blue(c)
        return (r>145 && r>g+65 && (r>b+55 || b>105)) ||
            (r>170 && g>65 && r>b+90 && g>b+45) ||
            (b>125 && g>75 && b>r+50 && g>r+30)
    }
    private fun gold(c:Int):Boolean = red(c)>180 && green(c)>85 && blue(c)<110 && red(c)>blue(c)+85
    private fun cyan(c:Int):Boolean = blue(c)>130 && green(c)>75 && blue(c)>red(c)+55
    fun detect(p:IntArray,w:Int,h:Int):Detection {
        if(w<100 || h<w || p.size!=w*h) return Detection()
        fun at(x:Int,y:Int)=p[y.coerceIn(0,h-1)*w+x.coerceIn(0,w-1)]
        val counts=IntArray(w)
        for(x in w/5 until w*4/5) for(y in h/10 until h*4/5) if(line(at(x,y))) counts[x]++
        var a=-1; var b=-1; var best=0
        for(x in w/4 until w/2) for(z in w/2 until w*4/5) {
            if(z-x !in (w*.20).toInt()..(w*.32).toInt() || abs(x+z-w)>w*.13) continue
            val score=counts[x]+counts[z]
            if(min(counts[x],counts[z])>h*.26 && score>best) {a=x;b=z;best=score}
        }
        if(a<0) return Detection()
        val ys=ArrayList<Int>()
        for(y in 0 until h) if((-1..1).any { line(at(a+it,y)) } && (-1..1).any { line(at(b+it,y)) }) ys.add(y)
        if(ys.size<h*.28) return Detection()
        val top=ys[(ys.size*.015).toInt()]; val bottom=ys[(ys.size*.985).toInt()]
        val l=(b-a).toFloat()
        if(bottom-top !in (l*3.1).toInt()..(l*4.6).toInt()) return Detection()
        val road=Road(a,b,top,bottom)
        fun ratio(x:Int,y:Int,rx:Float,ry:Float,pred:(Int)->Boolean):Float {
            val dx=max(1,(rx*l).roundToInt()); val dy=max(1,(ry*l).roundToInt()); var n=0;var total=0
            for(yy in y-dy..y+dy step 2) for(xx in x-dx..x+dx step 2) {total++; if(pred(at(xx,yy))) n++}
            return n.toFloat()/total
        }
        fun shift(v:Float)=(v*l).roundToInt()
        var player:Mark?=null
        for(x in a-shift(.78f)..b+shift(.78f) step 2) {
            val lane=(0..2).minByOrNull { abs(x-road.center(it)) }!!
            for(y in bottom-shift(.83f)..bottom-shift(.38f) step 2) {
                val front=ratio(x,y-shift(.32f),.11f,.04f,::white)
                val rear=(ratio(x-shift(.14f),y,.03f,.20f,::white)+ratio(x+shift(.14f),y,.03f,.20f,::white))/2
                val center=ratio(x,y+shift(.12f),.095f,.045f,::white)
                val window1=ratio(x,y-shift(.18f),.09f,.045f,::dark)
                val window2=ratio(x,y+shift(.24f),.085f,.035f,::dark)
                val score=(front+rear+center+window1+window2)/5f
                if(front>.48f && rear>.35f && center>.55f && window1>.6f && score>.67f && score>(player?.score?:0f)) player=Mark(lane,x,y,"PLAYER",score)
            }
        }
        if(player==null) return Detection(road)
        val objects=ArrayList<Mark>()
        for(lane in 0..2) {
            val x=road.center(lane)
            val candidates=ArrayList<Mark>()
            for(y in top+shift(1.0f)..min(bottom-shift(.15f),player.y+shift(.25f)) step max(2,shift(.045f))) {
                if(lane==player.lane && abs(y-player.y)<shift(.52f)) continue
                val body=ratio(x,y,.13f,.11f,::color)
                val upper=ratio(x,y-shift(.25f),.12f,.065f,::color)
                val lower=ratio(x,y+shift(.26f),.12f,.065f,::color)
                val wind=ratio(x,y-shift(.13f),.09f,.05f,::dark)
                val car=(body+upper+lower+wind)/4
                val pit=ratio(x,y,.115f,.045f,::hole)
                val outer=ratio(x,y,.24f,.13f,::hole)
                val coin=ratio(x,y,.065f,.065f,::gold)
                val shield=ratio(x,y,.065f,.08f,::cyan)
                when {
                    body>.43f && (upper>.30f || lower>.30f) && wind>.23f && car>.40f -> candidates.add(Mark(lane,x,y,"CAR",car))
                    pit>.66f && outer<.67f -> candidates.add(Mark(lane,x,y,"PIT",pit))
                    coin>.65f && ratio(x,y,.20f,.23f,::gold)<.39f -> candidates.add(Mark(lane,x,y,"COIN",coin))
                    shield>.65f && ratio(x,y,.22f,.20f,::cyan)<.42f -> candidates.add(Mark(lane,x,y,"SHIELD",shield))
                }
            }
            val chosen=ArrayList<Mark>()
            for(c in candidates.sortedByDescending { it.score + if(it.kind=="CAR") .4f else if(it.kind=="PIT") .25f else 0f }) {
                if(chosen.none { abs(it.y-c.y)<shift(if(it.kind=="CAR" || c.kind=="CAR") .60f else .25f) }) chosen.add(c)
            }
            objects.addAll(chosen)
        }
        return Detection(road,player,objects)
    }
    fun decide(d:Detection):DrivingAction {
        val p=d.player?:return DrivingAction.STOP
        val r=d.road?:return DrivingAction.STOP
        val l=r.laneWidth.toFloat()
        fun gap(m:Mark)=(p.y-m.y)/l
        fun hazards(lane:Int)=d.objects.filter { it.lane==lane && (it.kind=="CAR" || it.kind=="PIT") && gap(it)>-.4f }
        fun nearest(lane:Int)=hazards(lane).minOfOrNull { gap(it) }?:10f
        val available=(max(0,p.lane-1)..min(2,p.lane+1)).filter { it!=p.lane && nearest(it)>1.65f }
        fun action(lane:Int)=if(lane<p.lane) DrivingAction.LEFT else DrivingAction.RIGHT
        if(abs(p.x-r.center(p.lane))>l*.16f) return DrivingAction.HOLD
        if(nearest(p.lane)<1.65f) return available.maxByOrNull { nearest(it) }?.let { action(it) }?:DrivingAction.HOLD
        // Rewards are secondary to keeping the current lane safe.
        val reward=d.objects.filter { it.lane in available && it.kind in setOf("COIN","SHIELD") && gap(it) in .65f..1.7f }
            .maxByOrNull { (if(it.kind=="SHIELD") 2f else 1f)-gap(it)*.2f }
        if(reward!=null && nearest(reward.lane)>2.1f) return action(reward.lane)
        return DrivingAction.HOLD
    }
}
