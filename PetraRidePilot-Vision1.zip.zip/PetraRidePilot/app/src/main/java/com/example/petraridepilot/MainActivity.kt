package com.example.petraridepilot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 32, 28, 24)
        }

        val title = TextView(this).apply {
            text = "Petra Ride Pilot · Vision 2"
            textSize = 24f
        }
        val intro = TextView(this).apply {
            text = "نسخة تجريبية للرؤية والقيادة. فعّل الصلاحيات، شغّل الالتقاط واللوحة، عاير زري اللعبة ثم START AUTO. استخدمها فقط في تجربة مسموحة. STOP AUTO يوقف التحكم فوراً."
            textSize = 16f
        }
        layout.addView(title)
        layout.addView(intro)

        layout.addView(makeButton("1) تفعيل خدمة التحكم") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        layout.addView(makeButton("2) السماح بالظهور فوق التطبيقات") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            } else {
                Toast.makeText(this, "الإذن مفعّل", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(makeButton("3) تشغيل لوحة التحكم العائمة") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "فعّل إذن الظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "تم طلب تشغيل اللوحة", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(makeButton("إيقاف لوحة التحكم") {
            stopService(Intent(this, OverlayService::class.java))
        })

        layout.addView(makeButton("بدء التقاط الشاشة") {
            val manager = getSystemService(android.media.projection.MediaProjectionManager::class.java)
            startActivityForResult(manager.createScreenCaptureIntent(), 42)
        })
        layout.addView(makeButton("إيقاف الالتقاط") {
            stopService(Intent(this, CaptureService::class.java))
        })
        layout.addView(makeButton("عرض آخر صورة محللة للعبة") {
            val image = android.widget.ImageView(this)
            val game = java.io.File(filesDir, "game-analysis.jpg")
            val file = if (game.exists()) game else java.io.File(filesDir, "capture.jpg")
            if (file.exists()) {
                image.setImageBitmap(android.graphics.BitmapFactory.decodeFile(file.path))
                android.app.AlertDialog.Builder(this).setView(image).setPositiveButton("OK", null).show()
            } else Toast.makeText(this, "لا توجد صورة بعد", Toast.LENGTH_SHORT).show()
        })
        setContentView(android.widget.ScrollView(this).apply { addView(layout) })
    }

    override fun onResume() { super.onResume(); PilotState.disarm() }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java).putExtra("code", resultCode).putExtra("data", data))
        }
    }

    private fun makeButton(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 10 }
        }
}
