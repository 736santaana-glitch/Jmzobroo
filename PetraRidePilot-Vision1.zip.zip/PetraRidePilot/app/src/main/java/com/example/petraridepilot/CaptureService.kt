package com.example.petraridepilot

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.WindowManager
import java.io.File
import kotlin.math.*

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val main = Handler(Looper.getMainLooper())
    private val worker = HandlerThread("PetraVision")
    private lateinit var handler: Handler
    private var last = 0L
    private var lastSave = 0L
    private var lastTap = 0L
    private var lastValid = 0L
    private var lastLane = -1
    private var laneFrames = 0
    private var previous: IntArray? = null
    @Volatile private var running = false
    override fun onCreate() { super.onCreate(); worker.start(); handler=Handler(worker.looper) }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { PilotState.disarm(); stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("capture", "Screen capture", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, CaptureService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        startForeground(7, Notification.Builder(this, "capture").setSmallIcon(android.R.drawable.ic_menu_camera).setContentTitle("Petra Pilot Vision 2").addAction(Notification.Action.Builder(null, "Stop", stop).build()).build())
        if (projection != null) return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val metrics = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val w = metrics.widthPixels; val h = metrics.heightPixels
            val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(intent.getIntExtra("code", Activity.RESULT_OK), data)
            projection = p
            p.registerCallback(object : MediaProjection.Callback() { override fun onStop() { PilotState.disarm(); stopSelf() } }, main)
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = r
            running=true; PilotState.capturing=true; PilotState.status="SEARCHING GAME"; PilotState.disarm()
            r.setOnImageAvailableListener({ source ->
                try {
                    source.acquireLatestImage()?.use { frame ->
                        val now = SystemClock.elapsedRealtime()
                        if (!running || now-last<65) return@use
                        last=now
                        val plane=frame.planes[0]
                        val padded=plane.rowStride/plane.pixelStride
                        val bitmap=Bitmap.createBitmap(padded,h,Bitmap.Config.ARGB_8888)
                        try {
                            bitmap.copyPixelsFromBuffer(plane.buffer)
                            val cropped=Bitmap.createBitmap(bitmap,0,0,w,h)
                            val sw=256; val sh=(h*sw.toFloat()/w).roundToInt()
                            val small=Bitmap.createScaledBitmap(cropped,sw,sh,true)
                            if(cropped!==bitmap && cropped!==small) cropped.recycle()
                            try { process(small, now, w, h) } finally { if(small!==bitmap) small.recycle() }
                        } finally { bitmap.recycle() }
                    }
                } catch(e:Exception) { PilotState.disarm(); PilotState.status="VISION ERROR"; android.util.Log.e("PetraVision","Frame error",e) }
            },handler)
            display=p.createVirtualDisplay("PetraVision",w,h,metrics.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,r.surface,null,handler)
        } catch(e:Exception) { android.util.Log.e("PetraVision","Capture failed",e); stopSelf() }
        return START_NOT_STICKY
    }
    private fun process(b:Bitmap, now:Long, fullW:Int, fullH:Int) {
        val w=b.width; val h=b.height; val pixels=IntArray(w*h)
        b.getPixels(pixels,0,w,0,0,w,h)
        val d=VisionEngine.detect(pixels,w,h)
        val r=d.road; val p=d.player
        if(r==null || p==null) {
            laneFrames=0; previous=null
            PilotState.status="SEARCHING GAME"
            if(now-lastValid>900) PilotState.disarm()
            if(now-lastSave>1000) { lastSave=now; save(b,"capture.jpg") }
            return
        }
        lastValid=now
        if(lastLane==p.lane) laneFrames++ else { lastLane=p.lane; laneFrames=1 }
        val action=VisionEngine.decide(d)
        PilotState.status="GAME L${p.lane+1} | ${d.objects.size} | ${action.name}"
        PilotState.lastGameFrame=now
        var moving=false
        previous?.let { prev ->
            if(prev.size==pixels.size) {
                var changed=0; var n=0
                for(y in r.top+r.laneWidth..p.y-r.laneWidth/2 step 5) for(x in r.a-r.laneWidth/3..r.b+r.laneWidth/3 step 5) {
                    if(x !in 0 until w || y !in 0 until h) continue
                    val a=pixels[y*w+x];val c=prev[y*w+x]; n++
                    if(abs((a and 255)-(c and 255))>8 || abs((a shr 16 and 255)-(c shr 16 and 255))>8) changed++
                }
                moving=n>0 && changed.toFloat()/n>.025f
            }
        }
        previous=pixels
        if(PilotState.armed && GameAccessibilityService.foregroundPackage!=PilotState.targetPackage) PilotState.disarm()
        if(PilotState.armed && moving && laneFrames>=2 && now-lastTap>=270 && action in setOf(DrivingAction.LEFT,DrivingAction.RIGHT)) {
            val left=action==DrivingAction.LEFT
            val x=if(left) PilotState.leftX else PilotState.rightX
            val y=if(left) PilotState.leftY else PilotState.rightY
            // Only allow calibrated button taps below the detected game road.
            val sx=x*w/fullW; val sy=y*h/fullH
            if(x in 0f..fullW.toFloat() && y in 0f..fullH.toFloat() && sy>r.bottom+r.laneWidth*.55f && sy<h &&
                (if(left) sx<r.a+r.laneWidth*.5f else sx>r.a+r.laneWidth*.5f)) {
                lastTap=now; laneFrames=0
                main.post {
                    if(PilotState.armed && PilotState.targetPackage!=null && PilotState.targetPackage==GameAccessibilityService.foregroundPackage && running) {
                        GameAccessibilityService.instance?.tapAt(x,y,45L)
                    }
                }
            } else { PilotState.disarm(); PilotState.status="CHECK CONTROL CALIBRATION" }
        }
        if(now-lastSave>=650) {
            lastSave=now
            val copy=b.copy(Bitmap.Config.ARGB_8888,true) ?: return
            try {
                val canvas=Canvas(copy); val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth=1.5f; textSize=9f }
                fun mark(m:Mark) {
                    val l=r.laneWidth.toFloat(); val car=m.kind=="CAR" || m.kind=="PLAYER"
                    paint.color=when(m.kind){"PLAYER"->Color.GREEN;"CAR","PIT"->Color.RED;"COIN"->Color.YELLOW;else->Color.CYAN}
                    paint.style=Paint.Style.STROKE
                    val dx=l*(if(car) .19f else .12f); val dy=l*(if(car) .36f else .10f)
                    canvas.drawRect(m.x-dx,m.y-dy,m.x+dx,m.y+dy,paint)
                    paint.style=Paint.Style.FILL; canvas.drawText(m.kind,m.x-dx,m.y-dy-2,paint)
                }
                paint.color=Color.GREEN; paint.style=Paint.Style.STROKE
                canvas.drawRect((r.a-r.laneWidth).toFloat(),r.top.toFloat(),(r.b+r.laneWidth).toFloat(),r.bottom.toFloat(),paint)
                mark(p); d.objects.forEach(::mark)
                paint.style=Paint.Style.FILL; paint.color=Color.WHITE; canvas.drawText("Vision 2: ${action.name}",8f,18f,paint)
                save(copy,"game-analysis.jpg")
            } finally { copy.recycle() }
        }
    }
    private fun save(b:Bitmap,name:String) {
        val tmp=File(filesDir,"$name.tmp")
        tmp.outputStream().use { b.compress(Bitmap.CompressFormat.JPEG,90,it) }
        tmp.renameTo(File(filesDir,name))
    }
    override fun onDestroy() {
        running=false; PilotState.disarm(); PilotState.capturing=false; PilotState.status="CAPTURE STOPPED"
        display?.release(); reader?.close(); projection?.stop(); projection=null
        worker.quitSafely(); super.onDestroy()
    }
}
