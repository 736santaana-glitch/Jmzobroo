# Build Petra Ride Pilot using only your Android phone

You need a free GitHub account. This guide uses GitHub Actions to build the APK in the cloud.

## A. Create a repository
1. In your phone browser, open https://github.com and sign in or create an account.
2. Open https://github.com/new
3. Repository name: `PetraRidePilot`
4. Select **Public** (easiest for a first-time workflow), check **Add a README file**, then create the repository.
   - If you prefer a private repository, use that, but the workflow and artifact access may look slightly different.

## B. Upload the project ZIP
1. Open your new repository page.
2. Tap **Add file** → **Upload files**.
3. Upload the file `PetraRidePilot-Android-Starter.zip` from your Downloads folder.
4. Commit the change.

## C. Add the build workflow
1. In the repository, tap **Add file** → **Create new file**.
2. For the filename, enter exactly: `.github/workflows/build.yml`
3. Open `build.yml` from the helper bundle, copy all its text, and paste it into the GitHub editor.
4. Tap **Commit changes**.

## D. Run the build
1. Open the repository's **Actions** tab.
2. Select **Build Petra Ride Pilot APK**.
3. Tap **Run workflow** → **Run workflow**.
4. Wait until the run finishes with a green check mark.
5. Open that run, scroll to **Artifacts**, and tap `PetraRidePilot-debug-apk` to download it.

## E. Install
1. Extract the downloaded artifact ZIP if your phone asks.
2. Tap `app-debug.apk`.
3. If Android blocks it, allow your browser or Files app to install unknown apps only if you trust the file you built.
4. Install and open the app.

## Important
This only builds the current prototype. It can calibrate and test taps, but it does not yet automatically recognize cars/coins/shields or drive itself. The project has not been tested on your specific HMD phone. Do not use automation if Petra Ride's contest rules prohibit it.
